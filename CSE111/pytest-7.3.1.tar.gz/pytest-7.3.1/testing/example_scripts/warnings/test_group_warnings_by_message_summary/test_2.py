from test_1 import func


def test_2():
    func("foo")
